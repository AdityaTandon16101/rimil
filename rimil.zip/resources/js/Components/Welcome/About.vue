<template>
  <div class="flex flex-col gap-6 lg:flex-row" id="about">
    <div class="hidden lg:block lg:w-1/2">
      <img src="/assets/about.png" alt="about" />
    </div>
    <div class="lg:w-1/2">
      <h4>About Us</h4>
      <h3>Who we are</h3>
      <p>
        The pain itself is a lot of pain Life's a great unmoored affair
        he is obliged when he rejects it from the easy times;
        please let people who are interested in the system open up and make them flexible. We can achieve even exciting
        however, if these measures are less likely to be assumed, those who are unaware of the troublesome finder are here
        or when he loves them. Everyone wants to know how to repudiate all their needs;
        there is no greater pleasure than pain, less pleasure in the services of the body
        and he rejects any hardship to be avoided. Soothes when you have to do something less
        we can be the main sage
        the architect of life rejecting the pleasures and the obligations of great pain must be repudiated only
        so that I can't explain my fault for choosing! Are we often obliged to do something else that can be avoided?
        She shuns all the labor of the Blessed One and receives nothing from the needs of the present. But
        to? Or like an architect, from which source do he hate for such a thing as much as that? Blinded by
        it flies unencumbered with the system to gain great pleasure. Blessed because, ready to please
        some pleasure in the mind of an architect with great debts worthy of his ancestors
        the main training period for them, so that we can avoid further discomfort
        please.
      </p>
    </div>
  </div>
</template>
