<script setup>
import Header from "@x/Header/Guest.vue";
import Footer from "@x/Footer/Guest.vue";
</script>

<template>
  <Header />
  <slot />
  <Footer />
</template>
