<x-welcome.hero />
<x-welcome.about />
<x-welcome.contact />