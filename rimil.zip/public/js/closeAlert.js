/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./resources/js/closeAlert.js":
/*!************************************!*\
  !*** ./resources/js/closeAlert.js ***!
  \************************************/
/***/ (() => {

eval("setTimeout(function () {\n  return document.querySelector('.alert').style.display = \"none\";\n}, 2500);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9yZXNvdXJjZXMvanMvY2xvc2VBbGVydC5qcz9mZTMzIl0sIm5hbWVzIjpbInNldFRpbWVvdXQiLCJkb2N1bWVudCIsInF1ZXJ5U2VsZWN0b3IiLCJzdHlsZSIsImRpc3BsYXkiXSwibWFwcGluZ3MiOiJBQUFBQSxVQUFVLENBQUM7QUFBQSxTQUFNQyxRQUFRLENBQUNDLGFBQVQsQ0FBdUIsUUFBdkIsRUFBaUNDLEtBQWpDLENBQXVDQyxPQUF2QyxTQUFOO0FBQUEsQ0FBRCxFQUFnRSxJQUFoRSxDQUFWIiwic291cmNlc0NvbnRlbnQiOlsic2V0VGltZW91dCgoKSA9PiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuYWxlcnQnKS5zdHlsZS5kaXNwbGF5ID0gYG5vbmVgLCAyNTAwKTsiXSwiZmlsZSI6Ii4vcmVzb3VyY2VzL2pzL2Nsb3NlQWxlcnQuanMuanMiLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./resources/js/closeAlert.js\n");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval-source-map devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./resources/js/closeAlert.js"]();
/******/ 	
/******/ })()
;